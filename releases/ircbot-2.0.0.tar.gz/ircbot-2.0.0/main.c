#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/file.h>
#include <sys/select.h>
#include <unistd.h>
#include <termios.h>

#include "bot.h"

void ssl_init_openssl() {
  SSL_load_error_strings();
  OpenSSL_add_ssl_algorithms();
}

static void state_init(bot_state_t *state) {
  memset(state, 0, sizeof(bot_state_t));
  state->status = S_NONE;
  state->log_type = DEFAULT_LOG_LEVEL;
  state->last_pong_time = time(NULL);
  state->nick_release_time = time(NULL) - NICK_TAKE_TIME;
  state->server_fd = -1;
  state->server_count = 0;
  state->mask_count = 0;
  state->op_mask_count = 0;
  state->trusted_bot_count = 0;
  srand(time(NULL));
}

static void state_destroy(bot_state_t *state) {
  for (int i = 0; i < state->server_count; i++) free(state->server_list[i]);
  for (int i = 0; i < state->mask_count; i++) free(state->auth_masks[i]);
  channel_list_destroy(state);
}

static void get_input(const char *prompt, char *buffer, size_t len) {
    printf("%s: ", prompt);
    fflush(stdout);

    char *result = fgets(buffer, len, stdin);
    (void)result;

    // Check if a newline was found. If not, the input was too long.
    // If it was too long, we need to read and discard the rest of the line.
    if (buffer[len - 1] != 0 && strchr(buffer, '\n') == NULL) {
        int c;
        while ((c = getchar()) != '\n' && c != EOF) { } // Clear rest of buffer
        // Set a special flag value for the wizard to check
        buffer[0] = 0; 
        buffer[1] = 0;
    } else {
        // Normal case: remove the trailing newline/carriage return
        buffer[strcspn(buffer, "\r\n")] = 0;
    }
}

static void get_password(const char *prompt, char *buffer, size_t len) {
    struct termios oldt, newt;
    printf("%s: ", prompt);
    fflush(stdout);
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~ECHO; // Turn off echo
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);

    // FIX: Capture the return value and cast the variable
    char *result = fgets(buffer, len, stdin);
    (void)result; // This silences the "unused variable" warning

    buffer[strcspn(buffer, "\r\n")] = 0;
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt); // Restore terminal
    printf("\n");
}

static bool get_confirmed_password(const char *prompt, char *buffer, size_t len) {
    char confirm_buffer[MAX_PASS];
    
    // 1. Get the first password
    get_password(prompt, buffer, len);
    
    // 2. Get the confirmation password
    get_password("Confirm password", confirm_buffer, sizeof(confirm_buffer));

    // 3. Validate and report error 
    if (strcmp(buffer, confirm_buffer) == 0) {
        printf("Passwords match. Accepted.\n");
        return true; 
    } else {
        printf("🚨 ERROR: Passwords do not match. Please try again.\n");
        // Clear the buffer holding the invalid attempt
        memset(buffer, 0, len); 
        return false; 
    }
}

// --- REVISED CONFIG WIZARD WITH VALIDATION LOOPS ---
static void run_config_wizard(void) {
    // Declare all buffers outside the configuration loop
    bot_state_t state;
    char config_pass[MAX_PASS];
    char mask_buf[MAX_MASK_LEN];
    char server_buf[MAX_BUFFER];
    char chan_buf[MAX_CHAN];
    char confirm_char[2];

    printf("--- IRC Bot Initial Setup ---\n");
    printf("No config file found. Let's create one.\n\n");

    // The main loop for the entire wizard, allowing for restarts
    do {
        // Reset state and buffers for a fresh start
        state_init(&state);
        memset(config_pass, 0, MAX_PASS);
        memset(mask_buf, 0, MAX_MASK_LEN);
        memset(server_buf, 0, MAX_BUFFER);
        memset(chan_buf, 0, MAX_CHAN);

        printf("==========================================\n");
        printf("         Starting Configuration Wizard      \n");
        printf("==========================================\n");

        // 1. CONFIG PASS 
printf("\n--- Setup Config Master Password ---\n");
        while (true) {
            // FIX for skipped prompt: Clear any leftover input (like a previous '\n')
            int c;
            while ((c = getchar()) != '\n' && c != EOF); 
            
            if (get_confirmed_password("Enter new config password (for BOT_PASS env var)", config_pass, MAX_PASS)) {
                break; // Exit loop on match
            }
            // Loop continues on mismatch
        }

        // 2. BOT NICK (Validation and retry loop)
printf("\n--- Setup Bot Nickname ---\n");
        while (true) {
            printf("Max allowed characters: %d\n", MAX_NICK - 1);
            get_input("Enter bot nick", state.target_nick, MAX_NICK); 

            // Validation: Check for non-empty AND that the input wasn't truncated (handled by get_input clearing the buffer on overflow)
            if (strlen(state.target_nick) > 0 && strlen(state.target_nick) < MAX_NICK) {
                // Input is clean and within bounds.
                strncpy(state.current_nick, state.target_nick, MAX_NICK - 1);
                state.current_nick[MAX_NICK - 1] = '\0';
                printf("Nick accepted: %s\n", state.target_nick);
                break;
            }
            // This error message now covers both empty input and truncated input.
            printf("🚨 ERROR: Invalid nick. Must be between 1 and %d characters and cannot be too long.\n", MAX_NICK - 1);
        }

        // 3. ADMIN PASSWORD 
printf("\n--- Setup Admin Password ---\n");
        // FIX for skipped prompt: Clear any leftover input before the first password
        int c;
        while ((c = getchar()) != '\n' && c != EOF); 
        while (!get_confirmed_password("Enter new bot ADMIN password", state.bot_pass, MAX_PASS)) {
            // Loop until passwords match.
            // FIX: Clear buffer again to prevent the inner loop from being skipped.
            while ((c = getchar()) != '\n' && c != EOF); 
        }

        // 4. ADMIN USERMASK (Validation and retry loop)
        printf("\n--- Setup Admin Usermask ---\n");
        while (true) {
            get_input("Enter your admin usermask (e.g., *!*@your.host)", mask_buf, MAX_MASK_LEN);
            if (strchr(mask_buf, '!') && strchr(mask_buf, '@') && strlen(mask_buf) > 5) {
                // Temporarily store the mask, it will be assigned later if confirmed.
                printf("Usermask accepted: %s\n", mask_buf);
                break;
            }
            printf("🚨 ERROR: Invalid usermask format. Please include both '!' and '@' (e.g., *!*@host).\n");
        }

        // 5. IRC SERVER (Validation and retry loop)
        printf("\n--- Setup IRC Server ---\n");
        while (true) {
            get_input("Enter IRC server (e.g., irc.efnet.org)", server_buf, MAX_BUFFER);
            if (strlen(server_buf) > 0 && strchr(server_buf, '.')) {
                // Temporarily store the server, it will be assigned later if confirmed.
                printf("Server accepted: %s\n", server_buf);
                break;
            }
            printf("🚨 ERROR: Invalid server format. Please ensure it's a valid hostname (e.g., irc.example.org).\n");
        }

        // 6. INITIAL CHANNEL (Validation and retry loop)
        printf("\n--- Setup Initial Channel ---\n");
        while (true) {
            get_input("Enter channel to join (e.g., #bots)", chan_buf, MAX_CHAN);
            if (chan_buf[0] == '#' && strlen(chan_buf) > 1) {
                // Temporarily store the channel, it will be assigned later if confirmed.
                printf("Channel accepted: %s\n", chan_buf);
                break;
            }
            printf("🚨 ERROR: Invalid channel format. Channel must start with '#' (e.g., #channel).\n");
        }

        // --- FINAL CONFIRMATION STEP ---
        printf("\n==========================================\n");
        printf("     Configuration Summary (Review)         \n");
        printf("==========================================\n");
        printf("Bot Nick:                   %s\n", state.target_nick);
        printf("Admin Usermask:             %s\n", mask_buf);
        printf("IRC Server:                 %s\n", server_buf);
        printf("Initial Channel:            %s\n", chan_buf);
        printf("Bot Pass / Admin Pass:      SET (Hidden)\n");
        printf("------------------------------------------\n");

        get_input("Does this configuration look correct? (Y/n)", confirm_char, sizeof(confirm_char));
        
        // If the user enters 'n' or 'N', the loop continues (restarts the wizard)
        if (confirm_char[0] == 'n' || confirm_char[0] == 'N') {
            printf("\nRestarting configuration wizard...\n\n");
            // state_destroy must be called to free allocated memory before we restart
            state_destroy(&state); 
            // The do-while condition will be true, restarting the loop
        } else {
            // User confirmed (Y or empty input) - break the do-while loop
            break; 
        }

    } while (true); // Loop until the user confirms the settings

    // Assign and duplicate memory ONLY after final confirmation
    state.auth_masks[state.mask_count++] = strdup(mask_buf);
    state.server_list[state.server_count++] = strdup(server_buf);
    channel_add(&state, chan_buf);

    // Write config and print startup instructions
    printf("\n--- Finalizing Configuration ---\n");
    config_write(&state, config_pass);
    printf("\nConfiguration saved to %s.\n", CONFIG_FILE);
    printf("You can now start the bot using:\n");
    printf("**%s=\"%s\" ./ircbot**\n", CONFIG_PASS_ENV_VAR, config_pass);
}

int main(int argc, char *argv[]) {

curl_global_init(CURL_GLOBAL_DEFAULT);
    // --- FIX: New argument parsing logic ---
    if (argc > 1 && strcmp(argv[1], "-c") == 0) {
        // Config creation mode
        if (access(CONFIG_FILE, F_OK) == 0) {
            fprintf(stderr, "Error: Config file '%s' already exists. Remove it first to run setup.\n", CONFIG_FILE);
            return 1;
        }
        run_config_wizard();
        return 0;
    }

  int pid_fd = open(PID_FILE, O_CREAT | O_RDWR, 0600);
  if (pid_fd == -1) {
    perror("Failed to open PID file");
    return 1;
  }

  if (flock(pid_fd, LOCK_EX | LOCK_NB) == -1) {
    if (errno == EWOULDBLOCK) {
      fprintf(stderr,
              "Error: Another instance of the bot is already running.\n");
    } else {
      perror("Failed to lock PID file");
    }
    close(pid_fd);
    return 1;
  }

  char pid_str[16];
  sprintf(pid_str, "%d\n", getpid());
  ssize_t bytes_written = write(pid_fd, pid_str, strlen(pid_str));
  (void)bytes_written;

  ssl_init_openssl();

  const char *startup_password = getenv(CONFIG_PASS_ENV_VAR);
  if (!startup_password) {
    fprintf(stderr, "Error: %s environment variable not set.\n",
            CONFIG_PASS_ENV_VAR);
    return 1;
  }

  printf("%s %s\n", BOT_NAME, BOT_VERSION);
  bot_state_t state;
  state_init(&state);

  state.pid_fd = pid_fd;
//strncpy(state.executable_path, argv[0], sizeof(state.executable_path) - 1);
//    state.executable_path[sizeof(state.executable_path) - 1] = '\0';

  if (realpath(argv[0], state.executable_path) == NULL) {
      fprintf(stderr, "Error: Could not find real path of executable: %s\n", strerror(errno));
      return 1;
  }

  strncpy(state.startup_password, startup_password,
          sizeof(state.startup_password) - 1);
  state.startup_password[sizeof(state.startup_password) - 1] = '\0';

  get_local_ip(&state);

#ifndef DEBUG
#else
  printf("[Entering DEBUG mode]\n");
#endif

  setup_signals();
// printf("[DEBUG] Attempting to load %s with password: %s\n", CONFIG_FILE, startup_password);
    // --- FIX: Check for config load failure ---
    if (!config_load(&state, state.startup_password, CONFIG_FILE)) {
        fprintf(stderr, "Error: Config file missing or incomplete.\n");
        fprintf(stderr, "Run with -c to create a new one.\n");
        remove(PID_FILE);
        return 1;
    }

//  config_load(&state, state.startup_password, CONFIG_FILE);

  state.server_list[state.server_count] = NULL;
  state.auth_masks[state.mask_count] = NULL;

  while (!(state.status & S_DIE) && !g_shutdown_flag) {
    irc_check_status(&state);
    channel_manager_check_joins(&state);
    if (state.server_fd == -1 && !(state.status & S_DIE)) {
      sleep(5);
      continue;
    }
    fd_set read_fds;
    FD_ZERO(&read_fds);
    if (state.server_fd != -1) {
      FD_SET(state.server_fd, &read_fds);
    }
    int max_fd = state.server_fd;
    struct timeval tv = {1, 0};
    int activity = select(max_fd + 1, &read_fds, NULL, NULL, &tv);
    if (activity < 0) {
      if (errno == EINTR) continue;
      perror("select() error");
      state.status |= S_DIE;
      continue;
    }
    if (activity > 0) {
      if (state.server_fd != -1 && FD_ISSET(state.server_fd, &read_fds)) {
        irc_handle_read(&state);
      }
    }
  }
  config_write(&state, state.startup_password);
  irc_disconnect(&state);
  state_destroy(&state);
  curl_global_cleanup();
 close(state.pid_fd); 
 remove(PID_FILE);
  return 0;
}
